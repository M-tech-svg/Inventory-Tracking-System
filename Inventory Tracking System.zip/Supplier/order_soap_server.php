<?php
//create a method to delete catalog for the respective catalogid
function delOrderEntry($OrderMatCode){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM orders WHERE OrderMatCode = '$OrderMatCode';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  if($row = mysqli_fetch_array($result))
	{
   	   $query = "DELETE FROM orders WHERE OrderMatCode = '$OrderMatCode';";
	   $result = $conn->query($query) or die("Could not execute sql command.");
	   mysqli_close($conn);
	   echo "record removed";
	   return "record removed";
	}
	else
	{
	 	mysqli_close($conn);
		echo "record not found";
	 	return "record not found";
	}
}

//create a method to show (view) all the record
function getOrderEntry($OrderMatCode) { 
   $conn = new mysqli("localhost", "root", "","assignment");
  
  
/*   if($OrderMatCode==""||$OrderMatCode==null){
	  $query = "SELECT OrderId,OrderMatCode,MatName,OrderDate,OrderQty,SuppQty,SuppRate,
				if(RqstStatus="."O".","."OPEN".","."CLOSE"."),RqstClose 
				FROM orders, materialmaster where MatCode  = OrderMatCode;";
	}
	else {
	  O=OPEN,R=REPLIED,A=ACCEPT,D=DECLINE,V=RCV*/
	  $query = "SELECT OrderId,OrderMatCode,Material_ID MatCode, Material_Name MatName,OrderDate,OrderQty,SuppQty,SuppRate,
				CASE
				WHEN RqstStatus = 'O' THEN 'OPEN'
				WHEN RqstStatus = 'R' THEN 'REPLIED'
				WHEN RqstStatus = 'A' THEN 'ACCEPTED'
				WHEN RqstStatus = 'D' THEN 'DECLINED'
				WHEN RqstStatus = 'V' THEN 'RCV'
				END AS RqstStatus,
				CASE
				WHEN RqstClose = 'Y' THEN 'YES'
				ELSE 'NO'
				END AS RqstClose
				FROM orders, supplier_inventory where Material_ID  = OrderMatCode;";

	//}
  
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  mysqli_close($conn);

	$response = "<table border=1>
		 			<tr>
						<th>Order ID</th>
						<th>Order MatCode</th>
						<th>Materail Name</th>
						<th>Order Date</th>
						<th>Order Qty</th>					
						<th>Supplier Qty</th>
						<th>Supplier Rate</th>
						<th>Request Status</th>
						<th>Closed (Y/N)</th>
						<th>Edit</th>					
    				</tr>";
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
	 	 $response = $response."
		  <tr>
			<td>".$row['OrderId']."</td>
			<td>".$row['OrderMatCode']."</td>
			<td>".$row['MatName']."</td>			
    		<td>".$row['OrderDate']."</td>
			<td align='right'>".$row['OrderQty']."</td>
			<td align='right'>".$row['SuppQty']."</td>
			<td align='right'>".$row['SuppRate']."</td>
			<td>".$row['RqstStatus']."</td>
			<td>".$row['RqstClose']."</td>
			<td><a href=ReplyRequest.php?OrderId=".$row['OrderId']." class='link'><img alt='Edit'   title='Edit'   src='images/edit.png' width='15px' height='15px' hspace='10' />
			<input type='submit' name='menu' id='menu' value='Menu'  formaction='suppliermenu.php'/>
			</a>
				
			</td>

		  </tr>";
		
		
		$count++;
	} 
	$response = $response."</table>";

	echo $response;
	return $response;
} 



//create edit method to allow data update
function editOrderEntry($OrderId, $SuppQty, $SuppRate, $RqstStatus){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM orders WHERE OrderId = '$OrderId';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  if($row = mysqli_fetch_array($result))
	{
    	$query = "UPDATE orders SET SuppQty = '$SuppQty',
									SuppRate = '$SuppRate',
									RqstStatus = '$RqstStatus'
									WHERE OrderId = '$OrderId';";
  	
		if($conn->query($query))
  		{
  		 	mysqli_close($conn);
			echo "Record edited";
			return "Record edited";
  		}
  		else
		{
			mysqli_close($conn);
			echo "fail";
			return "fail.";
		}  
	}
	else
	{
	 		mysqli_close($conn);
			echo "record not found";
	 		return "record not found";
	}	
}




//create the add method
function addOrderEntry($o,$q){
	//create connection to mysql
	$conn = new mysqli("localhost","root", "", "assignment");	
	
	//check if catalog exist or not in the database. if exist, return duplicate record,
	//otherwise, add into database table called catalog
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
  	}
  	echo "Connected successfully";
  	
  	$query = "SELECT * FROM orders WHERE OrderMatCode = '$o';";
  	
  	$result = $conn->query($query) or die("Could not execute sql command.");
  	if($row = mysqli_fetch_array($result))
	{  
	 		mysqli_close($conn); 
	 		return "Duplicate record.";
	}
	else
	{	
		$query = "INSERT INTO orders (OrderMatCode, OrderQty) VALUES ('$o', '$q');";
    
  	if($conn->query($query))
  	{
  	 	mysqli_close($conn);
  		return "Record added";
  	}
  	else
  	{
  	  mysqli_close($conn);
  		echo "fail";
  		return "fail.";
  	}  
	}	
}

ini_set("soap.wsdl_cache_enabled", "0"); 
$server = new SoapServer("order.wsdl"); 		//specify the wsdl file
$server->addFunction("getOrderEntry"); 
$server->addFunction("delOrderEntry");
$server->addFunction("addOrderEntry");
$server->addFunction("editOrderEntry");
$server->handle(); 

?>