<?php

$OrderId = $_POST['OrderId'];
$SuppQty = $_POST['SuppQty'];
$SuppRate = $_POST['SuppRate'];
$RqstStatus = $_POST['RqstStatus'];


// creating soapClient object & specify the wsdl file
$client = new SoapClient("order.wsdl"); 
$response = $client->editOrderEntry($OrderId, $SuppQty, $SuppRate, $RqstStatus);
	
echo $response;

?>




