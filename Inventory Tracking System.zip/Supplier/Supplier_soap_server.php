<?php
//$c = $_POST['catalog'];
//$j = $_POST['journal'];
//$s = $_POST['section'];
//$e = $_POST['edition'];
//$t = $_POST['title'];
//$a = $_POST['author'];

//test by calling the method 
//addCatalogEntry($c, $j, $s, $e, $t, $a);
//editCatalogEntry($c, $j, $s, $e, $t, $a);
//getCatalogEntry("1");
//delCatalogEntry($c);


//create a method to delete catalog for the respective catalogid
function delSupplierEntry($supplier_Id){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM supplier WHERE supplier_id = '$supplier_Id';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  if($row = mysqli_fetch_array($result))
	{
   	   $query = "DELETE FROM supplier WHERE supplier_id = '$supplier_Id';";
	   $result = $conn->query($query) or die("Could not execute sql command.");
	   mysqli_close($conn);
	   echo "Supplier removed";
	   return "Supplier removed";
	}
	else
	{
	 	mysqli_close($conn);
		echo "Supplier not found";
	 	return "Supplier not found";
	}
}

//create a method to show (view) all the record by catalog id
function getSupplierEntry($supplier_Id) { 
   $conn = new mysqli("localhost", "root", "","assignment");
  
  
   if($supplier_Id==""||$supplier_Id==null){
	  $query = "SELECT * FROM supplier;";
	}
	else {
	  $query = "SELECT * FROM supplier WHERE supplier_Id = '$supplier_Id';";
	}
  
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  mysqli_close($conn);

	$response = "<table border=1>
		 			<tr><th>SUPPLIER_ID</th>
    					<th>SUPPLIER_NAME</th>
						<th>CONTACT_NO</th>
						<th>ADDRESS</th>
    				</tr>";
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
	 	 $response = $response."
		  <tr>
			<td>".$row['SUPPLIER_ID']."</td>
    		<td>".$row['SUPPLIER_NAME']."</td>
			<td>".$row['CONTACT_NO']."</td>
			<td>".$row['ADDRESS']."</td>
		  </tr>";
		
		
		$count++;
	} 
	$response = $response."</table>";

	echo $response;
	return $response;
} 



//create edit method to allow data update
function editSupplierEntry($s,$n,$c,$a){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM supplier WHERE supplier_id = '$s';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  if($row = mysqli_fetch_array($result))
	{
    	$query = "UPDATE supplier SET supplier_name = '$n',contact_no = '$c',
		address = '$a' WHERE supplier_id = '$s';";
  	
		if($conn->query($query))
  		{
  		 	mysqli_close($conn);
			echo "Supplier edited";
			return "Supplier edited";
  		}
  		else
		{
			mysqli_close($conn);
			echo "fail";
			return "fail.";
		}  
	}
	else
	{
	 		mysqli_close($conn);
			echo "Supplier not found";
	 		return "Supplier not found";
	}	
}




//create the add method
function addSupplierEntry($s , $n,  $c, $a){
	//create connection to mysql
	$conn = new mysqli("localhost","root", "", "assignment");	
	
	//check if catalog exist or not in the database. if exist, return duplicate record,
	//otherwise, add into database table called catalog
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
  	}
  	echo "Connected successfully";
  	
  	$query = "SELECT * FROM supplier WHERE supplier_id = '$s';";
  	
  	$result = $conn->query($query) or die("Could not execute sql command.");
  	if($row = mysqli_fetch_array($result))
	{  
	 		mysqli_close($conn); 
	 		return "Duplicate supplier.";
	}
	else
	{	
		$query = "INSERT INTO supplier (supplier_id, supplier_name,contact_no,address) VALUES ('$s', '$n', '$c', '$a');";
    
  	if($conn->query($query))
  	{
  	 	mysqli_close($conn);
  		return "Supplier added";
  	}
  	else
  	{
  	  mysqli_close($conn);
  		echo "fail";
  		return "fail.";
  	}  
	}	
}

ini_set("soap.wsdl_cache_enabled", "0"); 
$server = new SoapServer("supplier.wsdl"); 		//specify the wsdl file
$server->addFunction("getSupplierEntry"); 
$server->addFunction("delSupplierEntry");
$server->addFunction("addSupplierEntry");
$server->addFunction("editSupplierEntry");
$server->handle(); 

?>