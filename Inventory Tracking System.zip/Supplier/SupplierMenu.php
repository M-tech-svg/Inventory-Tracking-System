<?php 
	include('Supplierfunctions.php');
	if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: Supplierlogin.php');
}
?>

<!Doctype Html>
<Html>   
<Head>    
<head>
	<title>Supplier Home Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Supplier Home Page</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
	    <img src="user_profile.png" width="400" 
     height="500" alt="User profile">

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="SupplierMenu.php?logout='1'" style="color: red;">logout</a>
					</small>

				<?php endif ?>
			</div>
		</div>
	</div>
</body>

</Head>
<Body> 
<header>
<nav>
<ul>
<li>
<a href="http://localhost/Supplier/Suppliermaster.html"> Supplier Master </a>
</li>
<li>
<a href="http://localhost/Supplier/Supplierinventory.html"> Supplier Inventory </a>
</li>
<li>
<a href="http://localhost/Supplier/order_view_data.php">Reply Requests</a>
</li>
</ul>
</nav>
</header>
</Body> 
</Html>

 
<style type=text/css> 
body 
{
height: 125vh;
margin-top: 80px;
padding: 30px;
background-size: cover;
font-family: sans-serif;
}
header {
background-color: #A9A9A9;
position: fixed;
left: 0;
right: 0;
top: 5px;
height: 30px;
display: flex;
align-items: center;
box-shadow: 0 0 25px 0 black;
}
header * {
display: inline;
}
header li {
margin: 20px;
}
header li a {
color: #F8F8FF;
text-decoration: none;
}
</style> 
