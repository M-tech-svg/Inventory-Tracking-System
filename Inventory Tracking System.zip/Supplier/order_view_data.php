<?php
//$o = $_POST['OrderMatCode'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("order.wsdl"); 

	
 $response = $client->getOrderEntry();
	
  	echo $response;

?>

