<?php
$s = $_POST['supplier_id'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("supplier.wsdl"); 

	
 $response = $client->getSupplierEntry($s);
	
  	echo $response;

?>

