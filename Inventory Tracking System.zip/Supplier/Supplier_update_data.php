<?php

$s = $_POST['supplier_id'];
$n = $_POST['supplier_name'];
$c = $_POST['contact_no'];
$a = $_POST['address'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("supplier.wsdl"); 

	
	
	$response = $client->editSupplierEntry($s,$n,$c,$a);
	
  	echo $response;

?>




