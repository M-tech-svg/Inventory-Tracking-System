<?php

function delInventoryEntry($material_Id){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM supplier_inventory WHERE materia_id = '$material_Id';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  if($row = mysqli_fetch_array($result))
	{
   	   $query = "DELETE FROM supplier_inventory WHERE material_id = '$material_Id';";
	   $result = $conn->query($query) or die("Could not execute sql command.");
	   mysqli_close($conn);
	   echo "record removed";
	   return "record removed";
	}
	else
	{
	 	mysqli_close($conn);
		echo "record not found";
	 	return "record not found";
	}
}

//create a method to show (view) all the record by catalog id
function getInventoryEntry($material_Id) { 
   $conn = new mysqli("localhost", "root", "","assignment");
  
  
   if($material_Id==""||$material_Id==null){
	  $query = "SELECT * FROM supplier_inventory;";
	}
	else {
	  $query = "SELECT * FROM supplier_inventory WHERE material_Id = '$material_Id';";
	}
  
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  mysqli_close($conn);

	$response = "<table border=1>
		 			<tr><th>Material_ID</th>
    					<th>Material_Name</th>
						<th>Stock</th>
						<th>Price</th>
    				</tr>";
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
	 	 $response = $response."
		  <tr>
			<td>".$row['Material_ID']."</td>
    		<td>".$row['Material_Name']."</td>
			<td>".$row['Stock']."</td>
			<td>".$row['Price']."</td>
		  </tr>";
		
		
		$count++;
	} 
	$response = $response."</table>";

	echo $response;
	return $response;
} 


//create edit method to allow data update
function editInventoryEntry($m,$n,$s,$p){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM supplier_inventory WHERE material_id = '$m';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  if($row = mysqli_fetch_array($result))
	{
    	$query = "UPDATE supplier_inventory SET material_name = '$n',stock = '$s',
		price = '$p' WHERE material_id = '$m';";
  	
		if($conn->query($query))
  		{
  		 	mysqli_close($conn);
			echo "Inventory edited";
			return "Inventory edited";
  		}
  		else
		{
			mysqli_close($conn);
			echo "fail";
			return "fail.";
		}  
	}
	else
	{
	 		mysqli_close($conn);
			echo "Inventory not found";
	 		return "Inventory not found";
	}	
}




//create the add method
function addInventoryEntry($m,$n,$s,$p){
	//create connection to mysql
	$conn = new mysqli("localhost","root", "", "assignment");	
	
	//check if catalog exist or not in the database. if exist, return duplicate record,
	//otherwise, add into database table called catalog
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
  	}
  	echo "Connected successfully";
  	
  	$query = "SELECT * FROM supplier_inventory WHERE material_id = '$m';";
  	
  	$result = $conn->query($query) or die("Could not execute sql command.");
  	if($row = mysqli_fetch_array($result))
	{  
	 		mysqli_close($conn); 
	 		return "Duplicate Inventory.";
	}
	else
	{	
		$query = "INSERT INTO supplier_inventory (material_id, material_name,stock,price) VALUES ('$m', '$n', '$s', '$p');";
    
  	if($conn->query($query))
  	{
  	 	mysqli_close($conn);
  		return "Inventory added";
  	}
  	else
  	{
  	  mysqli_close($conn);
  		echo "fail";
  		return "fail.";
  	}  
	}	
}

ini_set("soap.wsdl_cache_enabled", "0"); 
$server = new SoapServer("supplier_inventory.wsdl"); 		//specify the wsdl file
$server->addFunction("getInventoryEntry"); 
$server->addFunction("delInventoryEntry");
$server->addFunction("addInventoryEntry");
$server->addFunction("editInventoryEntry");
$server->handle(); 

?>