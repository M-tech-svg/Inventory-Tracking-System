<?php
$m = $_POST['material_id'];
	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("supplier_inventory.wsdl"); 

	$response = $client->delInventoryEntry($m);
	
  	echo $response;


?>