<?php
$s = $_POST['supplier_id'];
$n = $_POST['supplier_name'];
$c = $_POST['contact_no'];
$a = $_POST['address'];
// creating soapClient object & specify the wsdl file
	$client = new SoapClient("supplier.wsdl"); 
//calling the function
		$response = $client->addSupplierEntry($s,$n,$c,$a);
	
echo $response;
?>