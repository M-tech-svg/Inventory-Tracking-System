<?php
$conn = mysqli_connect("localhost","root","","assignment");
/*
if(count($_POST)>0) {
	$sql = "UPDATE orders set OrderMatCode='" . $_POST["OrderMatCode"] . "', OrderQty='" . $_POST["OrderQty"] . "', SuppQty='" . $_POST["SuppQty"] . "', SuppRate='" . $_POST["SuppRate"] . "' WHERE OrderId ='" . $_POST["OrderId"] . "'";
	mysqli_query($conn,$sql);
	$message = "Record Modified Successfully";
}*/
$select_query = "SELECT
				OrderId,OrderMatCode,Material_ID MatCode,Material_Name MatName,
				OrderDate,OrderQty,SuppQty,SuppRate,
				RqstStatus RqstStatusCode,
				CASE
				WHEN RqstStatus = 'O' THEN 'OPEN'
				WHEN RqstStatus = 'R' THEN 'REPLIED'
				WHEN RqstStatus = 'A' THEN 'ACCEPTED'
				WHEN RqstStatus = 'D' THEN 'DECLINED'
				WHEN RqstStatus = 'V' THEN 'RCV'
				END AS RqstStatus,
				RqstClose RqstCloseCode,
				CASE
				WHEN RqstClose = 'Y' THEN 'YES'
				ELSE 'NO'
				END AS RqstClose
				FROM orders,supplier_inventory WHERE Material_ID = OrderMatCode 
				and OrderId ='" . $_GET["OrderId"] . "'";


$result = mysqli_query($conn,$select_query);
$row = mysqli_fetch_array($result);
?>

<html>
<head>
	<title>Order Request System</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
	<h2>Edit Order Request</h2>
</div>
  <form id="form1" name="form1" method="post" action="post">

    <table width="334" border="1">

<tr>
<td><label>Order ID</label></td>
<td><input type="text" name="OrderId" id="OrderId" class="txtField" value="<?php echo $row['OrderId']; ?>" readonly STYLE="color: #FF0000; text-align:center"></td>
</tr>

<tr>
<td><label>Material Code</label></td>	
<td>
<?php
$conn = mysqli_connect("localhost","root","","assignment");
$sql = "SELECT Material_ID MatCode, Material_Name MatName FROM supplier_inventory where Material_ID != '". $row['MatCode'] . "'";
$result1 = mysqli_query($conn,$sql);
?>

<select name="OrderMatCode" Id="OrderMatCode" class="txtField" disabled "true">
<?php
$ordmatcode = $row['MatCode'];
$ordmatname = $row['MatName'];

while ($row1 = $result1->fetch_assoc()) {
	$MatCode = $row1['MatCode'];
	$MatName = $row1['MatName'];
	echo "<option value='$MatCode'>$MatName</option>";
}
echo "<option value='$ordmatcode' selected>$ordmatname</option>"
?> 
</select>

</tr>


<tr>
<td><label>Order Quantity</label></td>
<td><input type="text" name="OrderQty" id="OrderQty" class="txtField" value="<?php echo $row['OrderQty']; ?>" readonly ; STYLE="color: #808080; text-align:right"></td>
</tr>
<tr>
<td><label>Supplier Quantity</label></td>
<td><input type="text" name="SuppQty" id="SuppQty" class="txtField" value="<?php echo $row['SuppQty']; ?>" STYLE="text-align:right"></td>
</tr>
        
<tr>
<td><label>Supplier Rate</label></td>
<td><input type="text" name="SuppRate" id="SuppRate" class="txtField" value="<?php echo $row['SuppRate']; ?>" STYLE="text-align:right"></td>
</tr>

<tr>
<td><label>Request Status</label></td>	
<td>
<select name="RqstStatus" Id="RqstStatus" class="txtField">
            <option value="O">OPENED</option>
            <option value="R">REPLIED</option>
            <option value="A">ACCEPTED</option>
			<option value="D">DECLINED</option>
			<option value="V">RCV</option>
<?php
$status = $row['RqstStatus'];
$statuscode = $row['RqstStatusCode'];
echo "<option value='$statuscode' selected>$status</option>"
?>
</select>
</tr>


<tr>
<td><label>Closed (Y/N)</label></td>	
<td>
<select name="RqstClose" Id="RqstClose" class="txtField">
            <option value="Y">YES</option>
            <option value="N">NO</option>
<?php
$close = $row['RqstClose'];
$closecode = $row['RqstCloseCode'];
echo "<option value='$closecode' selected>$close</option>"
?>
</select>
</tr>

<tr>
<!--<td colspan="2"><input type="submit" name="Add" id="Add" value="Add" formaction="order_add_data.php" />-->
<td colspan="2"><input type="submit" name="Update" id="Update" value="Update"  formaction="order_update_data.php"/>
<!--<input type="submit" name="Delete" id="Delete" value="Delete" formaction="order_delete_data.php" />-->
<input type="submit" name="View" id="View" value="View All" formaction="order_view_data.php" />
<input type="submit" name="menu" id="menu" value="Menu"  formaction="suppliermenu.php"/></td>
</tr>
      
    </table>
   
  </form>
</body>
</html>



