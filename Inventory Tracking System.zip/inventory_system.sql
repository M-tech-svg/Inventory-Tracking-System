-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2022 at 02:53 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderId` int(11) NOT NULL,
  `OrderMatCode` int(11) NOT NULL,
  `OrderDate` date NOT NULL DEFAULT current_timestamp(),
  `OrderQty` int(11) NOT NULL,
  `SuppQty` int(11) NOT NULL,
  `SuppRate` int(11) NOT NULL,
  `RqstStatus` varchar(1) NOT NULL DEFAULT 'O' COMMENT 'O=OPEN,R=REPLIED,A=ACCEPT,D=DECLINE,V=RCV',
  `RqstClose` varchar(1) NOT NULL DEFAULT 'N' COMMENT 'Y=YES;N=NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderId`, `OrderMatCode`, `OrderDate`, `OrderQty`, `SuppQty`, `SuppRate`, `RqstStatus`, `RqstClose`) VALUES
(5, 1, '2021-12-17', 2, 1, 200, 'D', 'Y'),
(7, 2, '2021-12-18', 1, 1, 150, 'V', 'Y'),
(8, 0, '2021-12-18', 2, 0, 0, 'O', 'N'),
(9, 4, '2021-12-18', 2, 0, 0, 'O', 'N'),
(10, 5, '2021-12-18', 3, 3, 150, 'V', 'N'),
(11, 4, '2021-12-18', 2, 0, 0, 'O', 'N'),
(12, 4, '2021-12-18', 2, 0, 0, 'O', 'N'),
(13, 4, '2021-12-18', 2, 0, 0, 'O', 'N'),
(14, 5, '2021-12-18', 3, 3, 250, 'V', 'N'),
(15, 1, '2021-12-20', 2, 2, 100, 'V', 'N'),
(16, 0, '2021-12-28', 9, 9, 100, 'V', 'Y'),
(17, 3, '2022-06-10', 4, 4, 500, 'V', 'Y');

--
-- Triggers `orders`
--
DELIMITER $$
CREATE TRIGGER `UpdateStock` BEFORE UPDATE ON `orders` FOR EACH ROW if NEW.RqstStatus ='V' THEN
  UPDATE supplier_inventory set Stock = Stock - NEW.SuppQty
  where Material_ID = OLD.OrderMatCode;
end if
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `retailer`
--

CREATE TABLE `retailer` (
  `RETAILER_ID` int(11) NOT NULL,
  `RETAILER_NAME` varchar(100) NOT NULL,
  `CONTACT_NO` int(11) NOT NULL,
  `ADDRESS` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `retailer`
--

INSERT INTO `retailer` (`RETAILER_ID`, `RETAILER_NAME`, `CONTACT_NO`, `ADDRESS`) VALUES
(1, 'Naqi Computers', 556677, 'KD'),
(2, 'Leroy', 3325425, 'Surian,Petaling Jaya'),
(3, 'Rehan', 6843468, 'Jeddah,Saudi Arabia'),
(4, 'Danish', 69454858, 'Petaling Jaya, Malaysia'),
(6, 'knki', 24354, 'dwdsegv'),
(1323, 'dsfsdfsdfdd', 21533, 'dw'),
(2134234235, 'Smart watch', 315153556, 'Jeddah,SA');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SUPPLIER_ID` int(11) NOT NULL,
  `SUPPLIER_NAME` varchar(50) NOT NULL,
  `CONTACT_NO` int(11) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SUPPLIER_ID`, `SUPPLIER_NAME`, `CONTACT_NO`, `ADDRESS`) VALUES
(1, 'egg', 69454858, 'sadsad'),
(4, 'Paul', 188554, 'Portsmouth,England'),
(7, '2e2', 825472452, 'dvfxb');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_inventory`
--

CREATE TABLE `supplier_inventory` (
  `Material_ID` int(11) NOT NULL,
  `Material_Name` varchar(500) NOT NULL,
  `Price` int(11) NOT NULL,
  `Stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier_inventory`
--

INSERT INTO `supplier_inventory` (`Material_ID`, `Material_Name`, `Price`, `Stock`) VALUES
(1, 'Printers', 3242, 265),
(2, 'LapTop', 0, 3221),
(0, 'Pencils', 150, 1215),
(4, 'Pencils', 150, 1224),
(5, 'Mouse', 300, 18),
(3, 'Smart watch', 900, -1254),
(6, 'Papers A4', 20, 500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `create_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `user_type`, `password`, `create_datetime`) VALUES
(0, 'naqi', 'naqiahmed@hotmail.com', 'Retailer', '202cb962ac59075b964b07152d234b70', '0000-00-00 00:00:00'),
(0, 'ahmed', 'ahmed@hotmail.com', 'Supplier', '202cb962ac59075b964b07152d234b70', '0000-00-00 00:00:00'),
(0, 'ahmed', 'ahmed@hotmail.com', 'Supplier', '202cb962ac59075b964b07152d234b70', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderId`);

--
-- Indexes for table `retailer`
--
ALTER TABLE `retailer`
  ADD PRIMARY KEY (`RETAILER_ID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SUPPLIER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `retailer`
--
ALTER TABLE `retailer`
  MODIFY `RETAILER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2134234236;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `SUPPLIER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
