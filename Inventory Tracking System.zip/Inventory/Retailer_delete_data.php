<?php
$r = $_POST['retailer_id'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("retailer.wsdl"); 

	$response = $client->delRetailerEntry($r);
	
  	echo $response;


?>