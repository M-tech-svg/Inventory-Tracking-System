<?php

$r = $_POST['retailer_id'];
$n = $_POST['retailer_name'];
$c = $_POST['contact_no'];
$a = $_POST['address'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("retailer.wsdl"); 

	
	
	$response = $client->editRetailerEntry($r,$n,$c,$a);
	
  	echo $response;

?>




