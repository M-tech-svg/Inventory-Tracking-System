<?php

$OrderId = $_POST['OrderId'];
$OrderMatCode = $_POST['OrderMatCode'];
$OrderQty = $_POST['OrderQty'];
$RqstStatus = $_POST['RqstStatus'];
$RqstClose = $_POST['RqstClose'];


// creating soapClient object & specify the wsdl file
$client = new SoapClient("order.wsdl"); 
$response = $client->editOrderEntry($OrderId, $OrderMatCode, $OrderQty, $RqstStatus, $RqstClose);
	
echo $response;

?>




