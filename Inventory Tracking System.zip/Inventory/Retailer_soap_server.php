<?php
//create a method to delete catalog for the respective catalogid
function delRetailerEntry($retailer_Id){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM retailer WHERE retailer_id = '$retailer_Id';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  if($row = mysqli_fetch_array($result))
	{
   	   $query = "DELETE FROM retailer WHERE retailer_id = '$retailer_Id';";
	   $result = $conn->query($query) or die("Could not execute sql command.");
	   mysqli_close($conn);
	   echo "record removed";
	   return "record removed";
	}
	else
	{
	 	mysqli_close($conn);
		echo "record not found";
	 	return "record not found";
	}
}

//create a method to show (view) all the record by catalog id
function getRetailerEntry($retailer_Id) { 
   $conn = new mysqli("localhost", "root", "","assignment");
  
  
   if($retailer_Id==""||$retailer_Id==null){
	  $query = "SELECT * FROM retailer;";
	}
	else {
	  $query = "SELECT * FROM retailer WHERE retailer_Id = '$retailer_Id';";
	}
  
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  mysqli_close($conn);

	$response = "<table border=1>
		 			<tr><th>RETAILER_ID</th>
    					<th>RETAILER_NAME</th>
						<th>CONTACT_NO</th>
						<th>ADDRESS</th>
						<th></th>
    				</tr>";
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
	 	 $response = $response."
		  <tr>
			<td>".$row['RETAILER_ID']."</td>
    		<td>".$row['RETAILER_NAME']."</td>
			<td>".$row['CONTACT_NO']."</td>
			<td>".$row['ADDRESS']."</td>
			<td><input type='submit' name='menu' id='menu' value='Menu'  formaction='Retailermenu.php'/></td>
		  </tr>";
		
		
		$count++;
	} 
	$response = $response."</table>";

	echo $response;
	return $response;
} 



//create edit method to allow data update
function editRetailerEntry($r,$n,$c,$a){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM retailer WHERE retailer_id = '$r';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  if($row = mysqli_fetch_array($result))
	{
    	$query = "UPDATE retailer SET retailer_name = '$n',contact_no = '$c',
		address = '$a' WHERE retailer_id = '$r';";
  	
		if($conn->query($query))
  		{
  		 	mysqli_close($conn);
			echo "Record edited";
			return "Record edited";
  		}
  		else
		{
			mysqli_close($conn);
			echo "fail";
			return "fail.";
		}  
	}
	else
	{
	 		mysqli_close($conn);
			echo "record not found";
	 		return "record not found";
	}	
}




//create the add method
function addRetailerEntry($r , $n,  $c, $a){
	//create connection to mysql
	$conn = new mysqli("localhost","root", "", "assignment");	
	
	//check if catalog exist or not in the database. if exist, return duplicate record,
	//otherwise, add into database table called catalog
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
  	}
  	echo "Connected successfully";
  	
  	$query = "SELECT * FROM retailer WHERE retailer_id = '$r';";
  	
  	$result = $conn->query($query) or die("Could not execute sql command.");
  	if($row = mysqli_fetch_array($result))
	{  
	 		mysqli_close($conn); 
	 		return "Duplicate record.";
	}
	else
	{	
		$query = "INSERT INTO retailer (retailer_id, retailer_name,contact_no,address) VALUES ('$r', '$n', '$c', '$a');";
    
  	if($conn->query($query))
  	{
  	 	mysqli_close($conn);
  		return "Record added";
  	}
  	else
  	{
  	  mysqli_close($conn);
  		echo "fail";
  		return "fail.";
  	}  
	}	
}

ini_set("soap.wsdl_cache_enabled", "0"); 
$server = new SoapServer("retailer.wsdl"); 		//specify the wsdl file
$server->addFunction("getRetailerEntry"); 
$server->addFunction("delRetailerEntry");
$server->addFunction("addRetailerEntry");
$server->addFunction("editRetailerEntry");
$server->handle(); 

?>