<?php
$o = $_POST['OrderMatCode'];
$q = $_POST['OrderQty'];


// creating soapClient object & specify the wsdl file
	$client = new SoapClient("order.wsdl"); 
//calling the function
		$response = $client->addOrderEntry($o,$q);
	
echo $response;
?>