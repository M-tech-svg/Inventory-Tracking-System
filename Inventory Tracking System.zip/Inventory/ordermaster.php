<!DOCTYPE html>
<html>
<head>
	<title>Order Request System</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
	<h2>Order Request System</h2>
</div>
  <form id="form1" name="form1" method="post" action="post">

    <table width="334" border="1">

<tr>
<td><label>Material Code</label></td>	
<td>
<?php
$conn = mysqli_connect("localhost","root","","assignment");
$sql = "SELECT * FROM supplier_inventory";
$result1 = mysqli_query($conn,$sql);
?>

<select name="OrderMatCode" class="txtField">
<?php 
while ($row1 = $result1->fetch_assoc()) {
	$MatCode = $row1['Material_ID'];
	$MatName = $row1['Material_Name'];
	echo "<option value='$MatCode'>$MatName</option>";
}
?>
</select>
</tr>

      <tr>
        <td>Order Quantity</td>
        <td><label for="OrderQty"></label>
        <input type="text" name="OrderQty" id="OrderQty" /></td>
      </tr>
      <tr>
        
      <tr>
      	<td colspan="2"><input type="submit" name="Add" id="Add" value="Add" formaction="order_add_data.php" />
      	<!--<input type="submit" name="Update" id="Update" value="Update"  formaction="order_update_data.php"/>
      	<input type="submit" name="Delete" id="Delete" value="Delete" formaction="order_delete_data.php" />-->
      	<input type="submit" name="View" id="View" value="View All" formaction="order_view_data.php" />
		<input type="submit" name="menu" id="menu" value="Menu"  formaction="RetailerMenu.php"/>
		</td>
    </tr>
      
    </table>
   
  </form>
</body>
</html>



