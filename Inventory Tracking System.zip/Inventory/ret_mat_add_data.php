<?php
$m = $_POST['material_id'];
$n = $_POST['material_name'];
$s = $_POST['stock'];
$p = $_POST['price'];

// creating soapClient object & specify the wsdl file
	$client = new SoapClient("retailer_inventory.wsdl"); 
//calling the function
		$response = $client->addInventoryEntry($m,$n,$s,$p);
	
echo $response;
?>