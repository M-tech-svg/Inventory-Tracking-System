<?php
$r = $_POST['retailer_id'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("retailer.wsdl"); 

	
 $response = $client->getRetailerEntry($r);
	
  	echo $response;

?>

