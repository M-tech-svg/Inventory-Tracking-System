<?php

function delInventoryEntry($material_Id){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM retailer_inventory WHERE material_id = '$material_Id';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  if($row = mysqli_fetch_array($result))
	{
   	   $query = "DELETE FROM retailer_inventory WHERE material_id = '$material_Id';";
	   $result = $conn->query($query) or die("Could not execute sql command.");
	   mysqli_close($conn);
	   echo "record removed";
	   return "record removed";
	}
	else
	{
	 	mysqli_close($conn);
		echo "record not found";
	 	return "record not found";
	}
}

//create a method to show (view) all the record by catalog id
function getInventoryEntry($material_Id) { 
   $conn = new mysqli("localhost", "root", "","assignment");
  
  
   if($material_Id==""||$material_Id==null){
	  $query = "SELECT OrderMatCode, MATERIAL_NAME, sum(SuppQty) Ret_inv FROM `orders`,supplier_inventory 
				WHERE  OrderMatCode = Material_ID
				and   RqstStatus = 'V'
				group by OrderMatCode,MATERIAL_NAME;";
	}
	else {
	  $query = "SELECT OrderMatCode, MATERIAL_NAME, sum(SuppQty) Ret_inv FROM `orders`,supplier_inventory 
				WHERE  OrderMatCode = Material_ID
				and   RqstStatus = 'V'				
				WHERE Material_ID = '$material_Id'
				group by OrderMatCode,MATERIAL_NAME;";
	}
  
  $result = $conn->query($query) or die("Could not execute sql command.");
  
  mysqli_close($conn);

	$response = "<table border=1>
		 			<tr><th>Material ID</th>
    					<th>Material Name</th>
						<th>Inventory</th>
						<th></th>
    				</tr>";
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
	 	 $response = $response."
		  <tr>
			<td>".$row['OrderMatCode']."</td>
    		<td>".$row['MATERIAL_NAME']."</td>
			<td>".$row['Ret_inv']."</td>
			
			<td><input type='submit' name='menu' id='menu' value='Menu'  formaction='retailermenu.php'/></td>
		  </tr>";
		
		
		$count++;
	} 
	$response = $response."</table>";

	echo $response;
	return $response;
} 


//create edit method to allow data update
function editInventoryEntry($m,$n,$s,$p){
  $conn = new mysqli("localhost", "root", "","assignment");
  
  $query = "SELECT * FROM retailer_inventory WHERE material_id = '$m';";
  $result = $conn->query($query) or die("Could not execute sql command.");
  if($row = mysqli_fetch_array($result))
	{
    	$query = "UPDATE retailer_inventory SET material_name = '$n',stock = '$s',
		price = '$p' WHERE material_id = '$m';";
  	
		if($conn->query($query))
  		{
  		 	mysqli_close($conn);
			echo "Record edited";
			return "Record edited";
  		}
  		else
		{
			mysqli_close($conn);
			echo "fail";
			return "fail.";
		}  
	}
	else
	{
	 		mysqli_close($conn);
			echo "record not found";
	 		return "record not found";
	}	
}




//create the add method
function addInventoryEntry($m,$n,$s,$p){
	//create connection to mysql
	$conn = new mysqli("localhost","root", "", "assignment");	
	
	//check if catalog exist or not in the database. if exist, return duplicate record,
	//otherwise, add into database table called catalog
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
  	}
  	echo "Connected successfully";
  	
  	$query = "SELECT * FROM retailer_inventory WHERE material_id = '$m';";
  	
  	$result = $conn->query($query) or die("Could not execute sql command.");
  	if($row = mysqli_fetch_array($result))
	{  
	 		mysqli_close($conn); 
	 		return "Duplicate record.";
	}
	else
	{	
		$query = "INSERT INTO retailer_inventory (material_id, material_name,stock,price) VALUES ('$m', '$n', '$s', '$p');";
    
  	if($conn->query($query))
  	{
  	 	mysqli_close($conn);
  		return "Record added";
  	}
  	else
  	{
  	  mysqli_close($conn);
  		echo "fail";
  		return "fail.";
  	}  
	}	
}

ini_set("soap.wsdl_cache_enabled", "0"); 
$server = new SoapServer("retailer_inventory.wsdl"); 		//specify the wsdl file
$server->addFunction("getInventoryEntry"); 
$server->addFunction("delInventoryEntry");
$server->addFunction("addInventoryEntry");
$server->addFunction("editInventoryEntry");
$server->handle(); 

?>