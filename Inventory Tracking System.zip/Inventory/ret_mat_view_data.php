<?php
//$m = $_POST['material_id'];

	// creating soapClient object & specify the wsdl file
	$client = new SoapClient("retailer_inventory.wsdl"); 

	
 $response = $client->getInventoryEntry();
	
  	echo $response;

?>

